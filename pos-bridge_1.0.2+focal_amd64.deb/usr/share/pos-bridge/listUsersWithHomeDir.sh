#!/bin/bash

for dir in /home/*/; do
	if [ -d "$dir" ]; then
		echo $dir
	fi
done
